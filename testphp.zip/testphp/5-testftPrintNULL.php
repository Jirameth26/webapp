<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Writing PHP Function which returns value</h2>
    <?php
      function printMe($param = NULL) {
        print $param;
      }
      printMe("This is test");
      printMe();
      printMe("<br />This is test");
      printMe();printMe();
    ?>
</body>
</html>