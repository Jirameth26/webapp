<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Dynamic Function Calls</h2>
    <?php
      function sayHello() {
        echo "Hello<br />";
      }
      $function_holder = "sayHello";
      $function_holder();
    ?>
</body>
</html>