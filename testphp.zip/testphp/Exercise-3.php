<html>
    <head>
        <title>Exercise-3</title>
    </head>
    <body>
        <?php 
            function test($x, $y) {
                return ($x >= 20 && $x <= 50) xor ($y >= 20 && $y <= 50);
            }

            var_dump(test(20, 84));
            var_dump(test(14, 50));
            var_dump(test(11, 45));
            var_dump(test(25, 40));
        ?>
    </body>
</html>